const { types } = secondTypeFlying
// console.log(types)
// const [firstType] = types 
