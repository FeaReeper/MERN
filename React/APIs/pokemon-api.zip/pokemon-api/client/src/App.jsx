import Pokemon from "./Components/Pokemon";

function App() {
  return (
    <>
      <div>
        <h1 className="text-center m-5">Pokemon API</h1>
        <Pokemon />
      </div>
    </>
  );
}

export default App;
