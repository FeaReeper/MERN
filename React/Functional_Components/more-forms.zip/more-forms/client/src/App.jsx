import { useState } from 'react'
import './App.css'
import ValidationForm from '../components/ValidationForm'

function App() {

  return (
    <>
      <ValidationForm/>
    </>
  )
}

export default App
