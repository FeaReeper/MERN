import React, {useState} from 'react'

const Advertisements = (props) => {
    return (
        <div className='ad'></div>
    )
}

export default Advertisements