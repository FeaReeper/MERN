import React, {useState} from 'react'
import './style.css'

const Header = (props) => {

    return (
        <div className='header'></div>
    )
}

export default Header