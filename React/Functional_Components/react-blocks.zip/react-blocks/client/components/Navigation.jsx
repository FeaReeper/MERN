import React, {useState} from 'react'

const Navigation = (props) => {
    return (
        <div className='nav'></div>
    )
}

export default Navigation