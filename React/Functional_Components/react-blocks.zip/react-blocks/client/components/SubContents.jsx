import React, {useState} from 'react'

const SubContents = (props) => {
    return (
        <div className='sub'></div>
    )
}

export default SubContents