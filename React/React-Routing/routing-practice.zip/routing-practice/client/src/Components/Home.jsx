import React from 'react'

function Home() {
  return (
    <div className='text-center mt-5'>
      <h1>Welcome</h1>
    </div>
  )
}

export default Home